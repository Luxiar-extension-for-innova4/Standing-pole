# Standing-pole
For decoration for your luxiar innova4 this is ideal for your lift.This is the pole,Yes,i know that it has alredy one including in the lift,But this is better
